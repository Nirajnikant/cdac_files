package main;

public class RedBlackNode {
		int data;
		RedBlackNode parent;
		RedBlackNode left;
		RedBlackNode right;
		int color;
}
