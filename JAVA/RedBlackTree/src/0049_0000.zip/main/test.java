package main;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RedBlackBST redBlack = new RedBlackBST();
		redBlack.insert(10);
		redBlack.insert(20);
		redBlack.insert(65);
		redBlack.insert(55);
		redBlack.insert(45);
		redBlack.insert(23);
		redBlack.deleteNode(65);

	}

}
